const broths = [
  {
    name: "Chicken Bone Broth",
    reviews: 7462,
    image: "Images/bs_i1.webp",
  },
  {
    name: "Beef Bone Broth",
    reviews: 8346,
    image: "Images/bs_i2.webp",
  },
  {
    name: "Turmeric Ginger",
    reviews: 1464,
    image: "Images/bs_i3.avif",
  },
  {
    name: "Mushroom Chicken",
    reviews: 4123,
    image: "Images/bs_i4.webp",
  },
];

function renderBroths() {
  const brothList = document.getElementById("broth-list");
  brothList.innerHTML = ""; // Clear existing content
  broths.forEach((broth) => {
    const brothItem = document.createElement("div");
    brothItem.className = "broth-item";
    brothItem.innerHTML = `
            <img src="${broth.image}" alt="${broth.name}">
            <h2>${broth.name}</h2>
            <p class="reviews">${broth.reviews.toLocaleString()} Reviews</p>
        `;
    brothList.appendChild(brothItem);
  });
}

renderBroths();
