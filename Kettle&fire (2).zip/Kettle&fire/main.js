let mainSection = document.getElementById("data-list-wrapper");

let sortAtoZ = document.getElementById("sortAtoZ");
let sortZtoA = document.getElementById("sortZtoA");
let sortLowtoHigh = document.getElementById("sortLowtoHigh");
let sortHightoLow = document.getElementById("sortHightoLow");
let sortOldtoNew = document.getElementById("sortOldtoNew");
let sortNewtoOld = document.getElementById("sortNewtoOld");

let productData = [];

function FetchData() {
  fetch("http://localhost:3000/products")
    .then((res) => res.json())
    .then((data) => {
      CardList(data), (productData = data);
    })
    .catch((err) => console.log(err));
}
FetchData();

function CardList(data) {
  const store = data.map((el) => Card(el.image, el.title, el.price));
  mainSection.innerHTML = store.join("");
}

function Card(image, title, price) {
  let SingleCard = `
      <div class="card" >
                <a href="description.html?title=${encodeURIComponent(
                  title
                )}&image=${encodeURIComponent(
    image
  )}&price=${encodeURIComponent(price)}">
                   <div class="card-img">
                       <img src=${image}>
                   </div>
                </a>
                   <div class="card-body">
                      <h6 class="card-title">${title}</h6>
                      <p class="card-price">${price}</p>
                     <button class="card-button"><a href="#">Add to Cart</a></button>

                      </div>
       </div>
    `;
  return SingleCard;
}
// sorting price

sortHightoLow.addEventListener("click", () => {
  const sortHtoL = productData.sort((a, b) => a.price - b.price);
  CardList(sortHtoL);
});

sortLowtoHigh.addEventListener("click", () => {
  const LtoH = productData.sort((a, b) => b.price - a.price);
  CardList(LtoH);
});
