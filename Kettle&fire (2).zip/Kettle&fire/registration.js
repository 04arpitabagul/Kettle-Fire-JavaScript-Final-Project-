const frist_name = document.getElementById("frist_name");
const last_name = document.getElementById("last_name");
const email = document.getElementById("email");
const password = document.getElementById("password");
const create_Account_button = document.getElementById("createBtn");
const sign_in = document.getElementById("sign_in");
const signin_email = document.getElementById("Signin_email");
const signin_password = document.getElementById("Signin_password");

let userDataArray = [];
create_Account_button.addEventListener("click", () => {
  let userData = {
    frist_name: frist_name.value,
    last_name: last_name.value,
    email: email.value,
    password: password.value,
  };
  userDataArray.push(userData);
  console.log(userDataArray);
  localStorage.setItem("userData", JSON.stringify(userDataArray));
});
